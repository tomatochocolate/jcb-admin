# hebao

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
npm run serve:testing
npm run serve:production
```

### Compiles and minifies for production
```
sudo chmod -R o+w dir
npm run build
npm run build:testing
npm run build:development
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
