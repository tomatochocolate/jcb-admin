module.exports = {
    plugins: {
        'autoprefixer': {},
        'postcss-import': {},
        'postcss-discard-comments': {
            removeAll: true
        }
    }
}
