<template>
    <div class="home">
    </div>
</template>
<script type="text/babel">

    export default {
        name: 'Home',
        async mounted () {}
    }
</script>
<style lang="scss" type="text/scss" scoped>
</style>
