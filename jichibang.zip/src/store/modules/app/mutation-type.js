/**
 * types
 * @author 请叫我蛋蛋哥 <76573917@qq.com>
 * @created 2017-04-09 21:39
 */
export const LOGIN = 'LOGIN'
export const LOGOUT = 'LOGOUT'

export const MENUS = 'MENUS'
export const CACHES = 'CACHES'
export const ROUTES = 'ROUTES'
export const HOMEROUTE = 'HOMEROUTE'
export const OPENNAMES = 'OPENNAMES'
export const ACTIVENAME = 'ACTIVENAME'
export const BREADCRUMBS = 'BREADCRUMBS'
export const CURRENTROUTE = 'CURRENTROUTE'
export const INITTAGS = 'INITTAGS'
export const ADDTAGS = 'ADDTAGSLIS'
export const REMOVETAGS = 'REMOVETAGS'
export const UPDATETAGS = 'UPDATETAGS'
export const CLOSEPAGE = 'CLOSEPAGE'
export const BREAKPOINTS = 'BREAKPOINTS'
