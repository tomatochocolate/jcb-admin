export default {
    data () {
        return {
            isReady: false
        }
    }
}
